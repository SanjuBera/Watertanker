package com.example.sanju.waterlevel;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Notification extends AppCompatActivity {

    private EditText minVal, maxVal,mobNumber;
    private Button stop,start;
    // static String minimum,maximum,mobile ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        start = (Button)findViewById(R.id.button1);
        stop = (Button)findViewById(R.id.button2);
        mobNumber = (EditText) findViewById(R.id.mobNum);
        minVal = (EditText) findViewById(R.id.minNum);
        maxVal = (EditText) findViewById(R.id.maxNum);


        // minimum = minVal.getText().toString();
        // maximum = maxVal.getText().toString();
        //mobile =  mobNumber.getText().toString();
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                SharedPreferences sharedPreferences = getSharedPreferences("myData", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("minimum",minVal.getText().toString());
                editor.putString("maximum",maxVal.getText().toString());
                editor.putString("mobile",mobNumber.getText().toString());

                editor.commit();


                Intent intent_start = new Intent(Notification.this,MyService.class);

                // intent_start.putExtra("minimum", minimum);
                //intent_start.putExtra("maximum", maximum );
                // intent_start.putExtra("mobile", mobile);
                startService(intent_start);
                System.out.println(minVal.getText().toString()+"   AND  "+maxVal.getText()+"  AND  "+mobNumber.getText());

            }
        });


        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent_stop = new Intent(Notification.this,MyService.class);
                stopService(intent_stop);
            }
        });

    }
}
