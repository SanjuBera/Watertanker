package com.example.sanju.waterlevel;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.support.design.widget.CoordinatorLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageButton;

import com.macroyau.thingspeakandroid.ThingSpeakChannel;
import com.macroyau.thingspeakandroid.model.ChannelFeed;

public class Charts extends AppCompatActivity {

    private ThingSpeakChannel tsPrivateChannel;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_charts);

        Intent intent = getIntent();
        String mApi_Key = intent.getStringExtra("api_key");
        String mChannelId = intent.getStringExtra("Channel_ID");

        System.out.println("Api Key is : "+mApi_Key);
        System.out.println("Channel Id is : "+mChannelId);

        String url = "http://thingspeak.com/channels/"+Integer.parseInt(mChannelId)+"/charts/1?api_key="+mApi_Key+"&dynamic=true&results=50&width=450&title=&height=280";
        String url2 = "http://thingspeak.com/channels/"+Integer.parseInt(mChannelId)+"/charts/2?api_key="+mApi_Key+"&dynamic=true&results=50&width=450&title=&height=280";
        String url3 = "http://thingspeak.com/channels/"+Integer.parseInt(mChannelId)+"/charts/3?api_key="+mApi_Key+"&dynamic=true&results=50&width=450&title=&height=280";

        System.out.println(url);


        ImageButton but = (ImageButton)findViewById(R.id.note);

        but.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(Charts.this,Notification.class);
                startActivity(intent2);
            }
        });


        WebView webview1 = (WebView)findViewById(R.id.chart1);
        webview1.getSettings().setJavaScriptEnabled(true);
        webview1.loadData("<iframe width=400 height=300 src=" +url+ "\" ></iframe> ","text/html",null);

        WebView webview2 = (WebView)findViewById(R.id.chart2);
        webview2.getSettings().setJavaScriptEnabled(true);
        webview2.loadData("<iframe width=400 height=300 src=" +url2+ "\" ></iframe> ","text/html",null);

        WebView webview3 = (WebView)findViewById(R.id.chart3);
        webview3.getSettings().setJavaScriptEnabled(true);
        webview3.loadData("<iframe width=400 height=300 src=" +url3+ "\" ></iframe> ","text/html",null);

        /*
        WebView webview4 = (WebView)findViewById(R.id.chart4);
        webview4.getSettings().setJavaScriptEnabled(true);
        webview4.loadData("<iframe width=400 height=300 src=" +url3+ "\" ></iframe> ","text/html",null);

        WebView webview5 = (WebView)findViewById(R.id.chart5);
        webview5.getSettings().setJavaScriptEnabled(true);
        webview5.loadData("<iframe width=400 height=300 src=" +url3+ "\" ></iframe> ","text/html",null);

        WebView webview6 = (WebView)findViewById(R.id.chart6);
        webview6.getSettings().setJavaScriptEnabled(true);
        webview6.loadData("<iframe width=400 height=300 src=" +url3+ "\" ></iframe> ","text/html",null);

        WebView webview7 = (WebView)findViewById(R.id.chart7);
        webview7.getSettings().setJavaScriptEnabled(true);
        webview7.loadData("<iframe width=400 height=300 src=" +url3+ "\" ></iframe> ","text/html",null);

        */
    }

}
