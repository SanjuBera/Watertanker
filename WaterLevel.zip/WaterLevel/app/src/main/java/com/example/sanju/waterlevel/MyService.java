package com.example.sanju.waterlevel;

/**
 * Created by Sanju on 20-03-2018.
 */

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.view.ContextMenu;
import android.widget.Toast;

import com.macroyau.thingspeakandroid.ThingSpeakChannel;
import com.macroyau.thingspeakandroid.model.ChannelFeed;

import java.io.IOException;



//import static com.example.morel.tsapplication.LoginActivity.Channel_ID;
//import static com.example.morel.tsapplication.LoginActivity.api_key;
//import static com.example.morel.tsapplication.notification.minimum;
//import static com.example.morel.tsapplication.notification.maximum;
//import static com.example.morel.tsapplication.notification.mobile;


/**
 * Created by morel on 08-01-2018.
 */

public class MyService extends Service {

    private volatile Thread t;
    private ThingSpeakChannel tsChannel;
    static String  api_key ,Channel_ID ,myMessage ,mobile ,maximum ,minimum ,Default= null ;
    private Context mContext;
    public boolean running , state;

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        mContext = getApplicationContext();

        running = true;
        state = true;

        Toast.makeText(this, "Service is started", Toast.LENGTH_SHORT).show();

        // minimum = intent.getStringExtra("minimum");
        // maximum = intent.getStringExtra("maximum");
        // mobile = intent.getStringExtra("mobile");

        SharedPreferences sharedPreferences = getSharedPreferences("myData", Context.MODE_PRIVATE);
        minimum = sharedPreferences.getString("minimum", Default);
        maximum = sharedPreferences.getString("maximum", Default);
        mobile = sharedPreferences.getString("mobile", Default);
        api_key = sharedPreferences.getString("api_key", Default);
        Channel_ID = sharedPreferences.getString("Channel_ID", Default);


    }
